<?php

/**
 * @name Qr
 * @description 扫码支付
 * @author houzhi
 * @time 2019/09/27 19:50
 */

namespace pay\now\pay;

class Qr extends NowPayBaseStrategy {

    protected $payType = 'qr';

    public function handle() {
        $reqParamStr = parent::handle();
        $res = $this->postCurl($this->config['gateway_url'], $reqParamStr);
        var_dump($res);exit;
    }


}