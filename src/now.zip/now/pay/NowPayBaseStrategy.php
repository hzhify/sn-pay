<?php
/**
 * @name NowPayBaseStrategy
 * @description
 * @author houzhi
 * @time 2019/09/27 14:18
 */

namespace pay\now\pay;

use pay\now\NowBaseStrategy;
use pay\util\Func;

abstract class NowPayBaseStrategy extends NowBaseStrategy {

    protected $payType = '';

    protected $reKeyArr = [
        'out_trade_no' => 'mhtOrderNo',
        'subject'      => 'mhtOrderName',
        'notify_url'   => 'notifyUrl',
        'return_url'   => 'frontNotifyUrl',
        'total_fee'    => 'mhtOrderAmt',
        'itime'        => 'mhtOrderStartTime',
    ];

    public function handle() {
        // 聚合动态码：https://nc.ipaynow.cn/s/R75dW3oyom4HKRo
        // 主扫：https://nc.ipaynow.cn/s/djpH99oFrjK3Eqw
        // 手机APP：https://nc.ipaynow.cn/s/xDGNR56JJK78m9e
        // 手机网页：https://nc.ipaynow.cn/s/7w7DjGRwwxrKfwM


        if ($this->validAndRefactorData()) {
            $this->data = array_merge($this->data, $this->config['req_fixed_params']); // 添加公有不变的参数
            $this->data['appId'] = $this->config["{$this->payType}_app_id"];
            Func::arrayReKey($this->data, $this->reKeyArr); // 字段重命名
            $this->data['mhtOrderStartTime'] = date('YmdHis', $this->data['mhtOrderStartTime']);
            $fields = 'funcode,version,appId,mhtOrderNo,mhtSubMchId,mhtOrderName,mhtOrderType,mhtCurrencyType,mhtOrderAmt,mhtOrderDetail,mhtOrderTimeOut,mhtOrderStartTime,notifyUrl,mhtCharset,deviceType,payChannelType,mhtReserved,mhtSubAppId,mhtLimitPay,mhtGoodsTag,mhtSignType,frontNotifyUrl';
            $this->data = Func::arrayFilterKey($this->data, $fields);
            $this->data['deviceType'] = $this->config['device_type'][$this->payType];
            $this->data['mhtOrderType'] = $this->config['order_type'][$this->payType];

            $reqParamStr = $this->getParamStr($this->data); // 拼接请求参数得到字符串
            $sign = md5("$reqParamStr&" . md5($this->config["{$this->payType}_app_key"])); // 生成签名字符串
            return "$reqParamStr&mhtSignature=$sign"; // 生成最终的请求参数字符串
        }
        return false;
    }

    /**
     * 校验和重构数据
     * @return bool
     */
    public function validAndRefactorData() {
        if (Func::validParams($this->data, ['subject', 'total_fee', 'notify_url', 'out_trade_no'])) {
            $this->data['mhtOrderDetail'] = $this->data['remark'] ?? $this->data['subject'];
            $this->data['mhtOrderTimeOut'] = $this->data['timeout'] ?? $this->config['timeout'];
            // $this->data['mhtReserved'] = $this->data['extend_info'] ?? '';
            return true;
        }
        return false;
    }

    public function getParamStr($data) {
        if (empty($data))
            return false;
        ksort($data);
        $str = '';
        foreach ($data as $k => $v) {
            if ($v == '' || $k == 'signature')
                continue;
            $str .= $k . '=' . $v . '&';
        }
        return rtrim($str, '&');
    }

    public function getSignStr($paramStr, $key) {
        return strtolower(md5($paramStr . md5($key)));
    }

    public function postCurl($url, $data) {
        $curl = curl_init(); // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        //curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        //curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
        curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包
        curl_setopt($curl, CURLOPT_TIMEOUT, 40); // 设置超时限制防止死循环
        curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
        $tmpInfo = curl_exec($curl); // 执行操作
        if (curl_errno($curl)) {
            return 'Errno' . curl_error($curl);//捕抓异常
        }
        curl_close($curl); // 关闭CURL会话
        return $tmpInfo; // 返回数据
    }


}