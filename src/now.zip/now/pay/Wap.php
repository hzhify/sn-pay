<?php

/**
 * @name Wap
 * @description 网页（H5）支付
 * @author houzhi
 * @time 2019/09/27 14:18
 */

namespace pay\now\pay;

class Wap extends NowPayBaseStrategy {

    protected $payType = 'wap';

    public function handle() {
        $reqParamStr = parent::handle();
        $res = $this->postCurl($this->config['gateway_url'], $reqParamStr);
        return $res;
    }


}