<?php

/**
 * @name NowBaseStrategy
 * @description
 * @author houzhi
 * @time 2019/09/27 14:18
 */

namespace pay\now;

use pay\BaseStrategy;
use pay\util\Func;

abstract class NowBaseStrategy implements BaseStrategy {
    protected $config = [];

    protected $data = [];

    protected $logFile;

    public function __construct($data, $config) {
        $this->data = $data;
        $this->config = $config;
        $this->logFile = 'pay-' . date('Ymd') . '.log';
    }

    /**
     * 验签方法
     * @param array $data 验签支付宝返回的信息，使用支付宝公钥。
     * @return bool
     */
    public function checkSign($data) {
        $aop = new \AopClient();
        $aop->alipayPublicKey = $this->config['alipay_public_key'];
        $result = $aop->rsaCheckV1($data, $this->config['alipay_public_key'], $this->config['sign_type']);
        return $result;
    }

}